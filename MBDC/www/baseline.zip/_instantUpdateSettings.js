function _instantUpdateSettings() {
return {
	"baseLineGUID": "619c6d6d98434fe1a51593bddd915f27",
	"baseURL": "https://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Please wait while the app is prepared for first-time use."
};
}