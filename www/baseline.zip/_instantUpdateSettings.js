function _instantUpdateSettings() {
return {
	"baseLineGUID": "9a2d05e812f341afa420ecabc49ddd03",
	"baseURL": "https://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": "Please wait while the app is prepared for first-time use."
};
}