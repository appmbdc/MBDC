function _phoneGapSettings() { 
 return {
    "appId": "com.yourcompany.yourapp",
    "preferences": null,
    "plugins": {}
};
}